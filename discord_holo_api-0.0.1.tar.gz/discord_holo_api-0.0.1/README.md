# discord-holo-api

## Requirements
- Python 3.6 and up - https://www.python.org/downloads/

# Install
```
pip i discord-holo-api
```

or

```
pip install discord-holo-api

```
# How to use

```py
import discord_holo_api
print(discord_holo_api.random("art"))


/*Available endpoint

["art", "ask","bite", "cry", "cuddle", "dance", "ego", "glare","highfive", "hug", "kiss", "lick", "nom", "pat", "poke", "pressf", "punch", "sex", "shoot", "slap", "slappope", "smug", "suicide", "tickle", "wasted", "wink"]
    
    */
```
    
## Links

*   [Website](http://discord-holo-api.ml/api/)
*   [Discord](https://discord.gg/TApdfmN)
*   [author](https://github.com/MakS1mKa28/discord-holo-api-py.git)